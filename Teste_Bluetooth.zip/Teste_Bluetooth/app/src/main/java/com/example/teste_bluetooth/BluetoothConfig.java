//package com.example.teste_bluetooth;
//
//
//import android.bluetooth.BluetoothAdapter;
//import android.bluetooth.BluetoothManager;
//import android.widget.Toast;
//
//public class BluetoothConfig {
//
//    private BluetoothAdapter bluetoothAdapter;
//
//    private void getBluetoothAdapter(){
//
//        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
//        if (bluetoothAdapter == null){
//            Toast.makeText(, "Device doesn't support Bluetooth", Toast.LENGTH_SHORT).show();
//        }
//
//    }
//
//
//
//
//}
