package com.example.teste_bluetooth;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.Serializable;
import java.util.Set;

public class MainActivity extends AppCompatActivity {


    private Button button;
    //    private BluetoothConfig bluetoothConfig;
    private static final int REQUEST_BLUETOOTH_PERMISSION = 1;
    private BluetoothAdapter bluetoothAdapter;
    private ActivityResultLauncher<Intent> bluetoothLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getId();
        getBluetoothAdapter();

        //Evento do Botão
        button.setOnClickListener(v -> toggleButton());

        bluetoothLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        // O Bluetooth foi ligado com sucesso
                        Toast.makeText(MainActivity.this, "Bluetooth ligado", Toast.LENGTH_SHORT).show();
                        searchDevice();
                    } else {
                        // O usuário não permitiu ligar o Bluetooth
                        Toast.makeText(MainActivity.this, "Não foi possível ligar o Bluetooth", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void toggleButton() {
        if (!bluetoothAdapter.isEnabled()) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED) {
                // Permissões já concedidas, ligar o Bluetooth
                Intent enableBluetoothIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                bluetoothLauncher.launch(enableBluetoothIntent);
            }
        }else {
            bluetoothAdapter.disable();
        }
    }

    private void searchDevice(){
    String deviceName = null;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.BLUETOOTH, Manifest.permission.BLUETOOTH_ADMIN}, REQUEST_BLUETOOTH_PERMISSION);
        }

        Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : devices) {
            if (device.getName() == "Pelicano"){
                deviceName = device.getName();
                Toast.makeText(this, deviceName, Toast.LENGTH_SHORT).show();
                Log.d("Econtrado", deviceName);
            }
            Log.d( "END","Device Name: " + device.getName() + "\nDevice Address: " + device.getAddress());
        }
    }

        private void getPairedDevices () {
            String deviceName;

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
            }
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();

            if (pairedDevices.size() > 0) {
                // There are paired devices. Get the name and address of each paired device.
                for (BluetoothDevice device : pairedDevices) {
                  if (device.getName() == "Pelicano"){
                      deviceName = device.getName();
                      Log.d("ENCONTRADO :", deviceName);

                  }
                    deviceName = device.getName();
                    String deviceHardwareAddress = device.getAddress(); // MAC address
                    Log.d("DEVICE NAME:", deviceName);
                    Log.d("MAC:", deviceHardwareAddress);
                }
            } else {
                Toast.makeText(this, "Sem dispositivos emparelhados", Toast.LENGTH_SHORT).show();
            }
        }

        private boolean getBluetoothAdapter () {

            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if (bluetoothAdapter == null) {
                Toast.makeText(this, "Device doesn't support Bluetooth", Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }

        private void getId () {
            button = findViewById(R.id.button);
        }

    }